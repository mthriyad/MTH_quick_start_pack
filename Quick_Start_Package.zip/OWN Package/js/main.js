(function($){
    
    $(document).ready(function(){
       $("button.uk-button").on("click", function(){
           return false;
       }); 
    });
    
})(jQuery);